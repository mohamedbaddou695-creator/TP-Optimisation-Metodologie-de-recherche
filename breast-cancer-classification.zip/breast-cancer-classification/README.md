# Breast Cancer Classification

Comparaison de **Random Forest** et **SVM** pour classer des tumeurs malignes ou bénignes avec Python et scikit-learn.

## Objectifs

- Explorer les données : valeurs manquantes, distributions et corrélations.
- Entraîner Random Forest et régler un SVM par `GridSearchCV`.
- Comparer accuracy, précision, rappel, F1, matrices de confusion et courbes ROC.

## Données

Le jeu **Breast Cancer Wisconsin (Diagnostic)** est chargé par `load_breast_cancer()` : 569 observations et 30 variables numériques. Aucun fichier CSV ou téléchargement manuel n'est nécessaire.

Classes : **0 = maligne**, **1 = bénigne**. Les métriques binaires et l'AUC présentées utilisent **bénigne** comme classe positive ; le rappel affiché ne représente donc pas la sensibilité aux cas malins.

## Structure

```text
breast-cancer-classification/
├── README.md
├── requirements.txt
├── .gitignore
├── notebooks/
│   └── breast_cancer_classification.ipynb
└── docs/
    ├── CHANGES.md
    └── GITHUB_GUIDE.md
```

## Installation — Windows CMD

Ouvrir CMD dans le dossier extrait :

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m jupyterlab
```

Ouvrir `notebooks/breast_cancer_classification.ipynb`, puis exécuter **Restart Kernel and Run All Cells**.

Sur macOS/Linux, remplacer l'activation par `source .venv/bin/activate`.

## Méthode

Séparation stratifiée : 80 % apprentissage et 20 % test, graine 42. La validation croisée à 5 plis utilise seulement l'apprentissage. La standardisation du SVM est apprise à l'intérieur de chaque pli avec un `Pipeline`. Le SVM est sélectionné selon le F1 de la classe bénigne, parmi six configurations (trois valeurs de C et deux noyaux).

## Résultats et reproductibilité

Les sorties du notebook fourni ont été effacées pour ne pas conserver les anciens scores issus de la fuite de cible. Exécuter le notebook pour obtenir les résultats corrigés. Les dépendances ne sont pas verrouillées ; leurs versions peuvent affecter les résultats.

Une seule séparation est utilisée : ce travail pédagogique ne constitue pas une validation clinique.

## Publication

Voir [le guide GitHub](docs/GITHUB_GUIDE.md) pour publier ce dossier. Voir [les corrections](docs/CHANGES.md) pour les changements apportés au notebook initial.
