# Publier sur GitHub — Windows CMD

## 1. Préparer le dépôt distant

Créer un nouveau dépôt nommé `breast-cancer-classification` dans ton compte GitHub. Description proposée : « Classification du cancer du sein : comparaison Random Forest et SVM avec scikit-learn ». Choisir la visibilité souhaitée. Ne pas initialiser le dépôt avec README, licence ou .gitignore : les fichiers existent déjà localement.

## 2. Ouvrir CMD dans le dossier extrait

Ouvrir le dossier `breast-cancer-classification` dans l'Explorateur Windows, saisir `cmd` dans la barre d'adresse et appuyer sur Entrée.

## 3. Publier

Remplacer `TON-PSEUDO` par ton identifiant GitHub dans l'URL.

```bat
git init
git config user.name "Halima Baddou"
git config user.email "halimabaddou62@gmail.com"
git add .
git status
git commit -m "Add breast cancer classification project"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/breast-cancer-classification.git
git push -u origin main
```

L'adresse e-mail du commit devient visible dans l'historique du dépôt. Tu peux utiliser l'adresse privée noreply affichée dans tes paramètres GitHub à sa place. Si GitHub demande une connexion, suivre l'authentification proposée par Git Credential Manager.

## 4. Mettre à jour

Après modification et vérification :

```bat
git add .
git diff --cached
git commit -m "Update analysis and documentation"
git push
```

Le dossier `.venv` est ignoré : il ne doit pas être envoyé. Pour réutiliser librement le projet, ajouter une licence adaptée après vérification des droits.
