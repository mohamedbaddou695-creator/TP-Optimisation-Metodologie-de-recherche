# Vérification

Toutes les cellules de code ont été exécutées dans leur ordre, dans un même espace Python avec un backend graphique non interactif, sans erreur.

- X : 569 observations et 30 variables, sans cible.
- Accuracy test Random Forest : 0,9561.
- Accuracy test SVM : 0,9825.

Ces valeurs correspondent à l’exécution de vérification ; elles peuvent varier selon les versions des dépendances. Les sorties du notebook restent effacées pour un dépôt propre.
